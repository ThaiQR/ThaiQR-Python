# -- Thai QR Generate -- 

<!-- ## How to use
### 1. Merchant with Promptpay
if want to use for Promptpay e.g. Mobile number, National id/Tax id, E wallet id and Bank Account  
 example
- Receive with Mobile number
- Receiver ID - 0987654321
- Amount : 1000.00
- One time usage

```

``` -->