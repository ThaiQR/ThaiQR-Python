#!/usr/bin/env python

from distutils.core import setup

if __name__ == '__main__':
    setup(name='ThaiQR',
        version='1.0.1',
        description='Thai QR Python library',
        author='Psskynyrd',
        author_email='pasupong.seelalek@gmail.com',
        # packages=['crc16'],
        #   url='https://www.python.org/sigs/distutils-sig/',
        #   packages=['distutils', 'distutils.command'],
        )